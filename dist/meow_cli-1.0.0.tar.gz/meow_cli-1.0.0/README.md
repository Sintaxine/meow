# meow

meow is a simple Python package that mimics the `cat` command.

## Installation

```bash
pip install .

